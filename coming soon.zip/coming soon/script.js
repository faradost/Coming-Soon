const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// **Set canvas dimensions**
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// **Define colors**
const colors = ["#2ecc40", "#ff4961", "#f7b733", "#9b59b6", "#3498db"];

// **Create particles**
const particles = [];
for (let i = 0; i < 100; i++) {
    particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: Math.random() * 2 - 1,
        vy: Math.random() * 2 - 1,
        radius: Math.random() * 5 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
    });
}

// **Animate particles**
function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < particles.length; i++) {
        const particle = particles[i];

        // Update particle position
        particle.x += particle.vx;
        particle.y += particle.vy;

        // Bounce off edges
        if (particle.x < 0 || particle.x > canvas.width) {
            particle.vx *= -1;
        }
        if (particle.y < 0 || particle.y > canvas.height) {
            particle.vy *= -1;
        }

        // Draw particle
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
        ctx.fillStyle = particle.color;
        ctx.fill();
    }

    requestAnimationFrame(animate);
}

animate();

// **On resize, update canvas dimensions and particle positions**
window.addEventListener("resize", () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    for (let i = 0; i < particles.length; i++) {
        particles[i].x = Math.random() * canvas.width;
        particles[i].y = Math.random() * canvas.height;
    }
});
